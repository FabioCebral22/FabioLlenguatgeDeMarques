const codigo = [];
const maxIntento = 5;
const input = document.getElementById("numero")
let cajasRest = document.getElementById("Result")
let tries = 0  
let info = document.getElementById("info")

/*1. Genera una constante CODIGO_SECRETO de tipo array de 5 número aleatorios entre 0 y 9 usando la libreria Math.random();*/
function codigoSecreto() {
    for (let i = 0; i < 5; i++) {
        codigo[i] = Math.floor((Math.random() * 10));
    }
}

codigoSecreto();
console.log(codigo)


function printCells(){
    let input = document.getElementById("numero").value;
    let cajasRest = document.getElementById("Result")
    let arrayInput = Array.from(input);
    
    
    
       
    for (let y=0;y<5; y++ ){
    let boxIterateColumna=cajasRest.children[0].children[y].children[0]
    boxIterateColumna.innerHTML=arrayInput[y]
                         
    if(arrayInput[y]==codigo[y]){
        boxIterateColumna.style.backgroundColor = 'green';
    }
    else if(codigo.includes(parseInt(arrayInput[y]))){
        boxIterateColumna.style.backgroundColor = 'yellow';
     }
    else {
    boxIterateColumna.style.backgroundColor = 'grey';
    }
}                  
    
    
    
  }

  function checkArrayEquality(_array1, _array2) {
    if (_array1 === null || _array2 === null)
        return false;
    if (_array1.length !== _array2.length)
        return false;
    for (var i = 0; i < _array1.length; ++i) {
        if (_array1[i] !== _array2[i])
            return false;
    }
    return true;
}

function checkFunction(){
  
    
    let input = document.getElementById("numero").value;
     let arrayInput = Array.from(input);
       let result = arrayInput.map(i=>Number(i));

       if(checkArrayEquality(result,codigo)===true){
        document.getElementById("cod1").innerHTML=codigo[0];
        document.getElementById("cod2").innerHTML=codigo[1];
        document.getElementById("cod3").innerHTML=codigo[2];
       document.getElementById("cod4").innerHTML=codigo[3];
        document.getElementById("cod5").innerHTML=codigo[4];
        iWinn()
       }
       else{
         nexTurn()
         
       if (tries>=maxIntento){
          for (i=0; i<5;i++){
            document.getElementById("cod1").innerHTML=codigo[0];
            document.getElementById("cod2").innerHTML=codigo[1];
            document.getElementById("cod3").innerHTML=codigo[2];
           document.getElementById("cod4").innerHTML=codigo[3];
            document.getElementById("cod5").innerHTML=codigo[4];
              imLoser();
          }

          
       }
       
       prueba();
      }  

}
          

;
 function iWinn(){
    
         info.innerHTML="Lo has conseguido!"
    
 };
 function imLoser(){
    document.getElementById("check").disabled = true;
     info.innerHTML="Has perdido"
 };

function createRow(){
    let input = document.getElementById("numero").value;
     let arrayInput = Array.from(input);
       let result = arrayInput.map(i=>Number(i));

    if (tries<5) {
        // for(a = 0; a<5; a++){
        //     let fila = document.getElementById('rowToClone')
        // }
        // const guessRow = document.getElementById("rowToClone");
        // const clonedRow = guessRow.cloneNode(true);
        // clonedRow.id =`rowToClone${maxIntento - tries}`;
        // console.log(clonedRow);
        const nuevaFila = `
        <div class="rowResult w100 flex wrap">
          <div class="w20">
            <div class="celResult flex"></div>
          </div>
          <div class="w20">
            <div class="celResult flex"></div>
          </div>
          <div class="w20">
            <div class="celResult flex"></div>
          </div>
          <div class="w20">
            <div class="celResult flex"></div>
          </div>
          <div class="w20">
            <div class="celResult flex"></div>
          </div>
        </div>`
        cajasRest.innerHTML=cajasRest.innerHTML+nuevaFila
    }
};
 
function nexTurn(){
  if(tries>=1){
    createRow();
  }
tries=tries+1

  
  info.innerHTML="Vuelve a intentarlo"
}
;

function prueba(){
  let input = document.getElementById("numero").value;
    let cajasRest = document.getElementById("Result")
    let arrayInput = Array.from(input);
   
  for (let y=0;y<5; y++ ){

    for (let j=0;j<5; j++ ){

      let boxIterateColumna=cajasRest.children[y].children[j].children[0]
      boxIterateColumna.innerHTML=arrayInput[j]               
      if(arrayInput[j]==codigo[j]){
          boxIterateColumna.style.backgroundColor = 'green';
      }
      else if(codigo.includes(parseInt(arrayInput[j]))){
          boxIterateColumna.style.backgroundColor = 'yellow';
       }
      else {
      boxIterateColumna.style.backgroundColor = 'grey';
      }
    }
  }

}
;

